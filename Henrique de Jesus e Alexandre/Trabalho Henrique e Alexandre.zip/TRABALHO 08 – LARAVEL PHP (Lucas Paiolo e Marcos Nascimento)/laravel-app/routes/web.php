<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppController;
use App\Http\Controllers\AuthController;

// Rotas de AppController
Route::get('/sobre', [AppController::class, 'sobre'])->name('sobre');
Route::get('/usuarios', [AppController::class, 'exibirUsuarios'])->name('usuarios');
Route::post('/usuarios/add', [AppController::class, 'addUsuario'])->name('add.usuario');
Route::get('/usuarios/{id}/editar', [AppController::class, 'editUsuario'])->name('edit.usuario');
Route::post('/usuarios/atualizar', [AppController::class, 'atualizar'])->name('atualizar.usuario');
Route::delete('/usuarios/{id}', [AppController::class, 'delUsuario'])->name('del.usuario');

// Rotas de AuthController
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware('auth')->name('dashboard');


Route::get('/', function () {
    return view('welcome');
});


Route::get('/sobre', [AppController::class, 'sobre']);


Route::get('/base', [AppController::class, 'base']);

Route::get('/usuarios', [AppController::class, 'exibirUsuarios']);

Route::post('/add-usuario', [AppController::class, 'addUsuario']);

Route::get('/edit-usuario/{id}', [AppController::class, 'editUsuario']);

//faz o update nos dados do usuario
Route::put('/atualizar/{id}', [AppController::class, 'atualizar']);

//deleta o usuario
Route::delete('/del-usuario/{id}', [AppController::class, 'delUsuario']);

Route::middleware('auth')->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

// Rota para exibir o formulário de login
Route::get('/login', function () {
    return view('login'); // Verifica se login.blade.php existe
})->name('login');

// Rota para processar o login
Route::post('/login', [AuthController::class, 'login'])->name('login');

// Rota para logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware('auth')->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');