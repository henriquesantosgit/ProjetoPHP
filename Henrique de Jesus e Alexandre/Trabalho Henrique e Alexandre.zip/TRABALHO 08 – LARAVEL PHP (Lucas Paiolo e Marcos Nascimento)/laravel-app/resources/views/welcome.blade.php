@extends ('base')

@section('titulo','Laravel')

@section('main')
<div id="container-flex">
    <div>
        <img src="https://freesvg.org/img/user-icon.png" alt="">
    </div>
  
        <form action="{{ route('register') }}" method="post">
            @csrf
            Nome:<br>
            <input type="text" name="fnome"><br>
            E-mail:<br>
            <input type="email" name="femail"><br>
            Senha:<br>
            <input type="password" name="fsenha"><br>
            <input type="submit" value="Cadastrar">
        </form>
    </div>
</div>

@endsection