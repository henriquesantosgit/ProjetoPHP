@extends('base')
@section('titulo','sobre')

@section('main')
    <h1>Sobre {{ $nome }}</h1>

    @if($nome== "Laravel")
    <p>Laravel é uma ferramenta de desenvolvimento web e framework PHP.</p>
    @endif
    <br>
    <hr>
    @for ($i=0; $i<=5;$i++)
    <p>Item {{ $i }}</p>
    @endfor
    <br>
    <hr>
    @foreach ($nomes as $nms )
    <p>Nome: {{ $nms }}</p>
    
    @endforeach
@endsection
<!-- <h1>sobre {{ $nome  }}</h1> -->
