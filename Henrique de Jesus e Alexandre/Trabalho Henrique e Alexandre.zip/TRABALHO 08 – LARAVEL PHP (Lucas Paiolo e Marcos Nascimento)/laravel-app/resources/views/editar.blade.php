@extends ('base')

@section('titulo','Laravel')

@section('main')
<div id="container-flex">
  
  
        <form action="/atualizar/{{$user->id}}" method="post">
            @csrf
            <!-- permite atualizar os usuários -->
            @method('put')

            Nome:<br>
            <input type="text" name="fnome" value="{{$user->nome}}"><br>
            E-mail:<br>
            <input type="email" name="femail" value="{{$user->email}}"><br>
    
            <input type="submit" value="Atualizar">
        </form>
    </div>
</div>

@endsection