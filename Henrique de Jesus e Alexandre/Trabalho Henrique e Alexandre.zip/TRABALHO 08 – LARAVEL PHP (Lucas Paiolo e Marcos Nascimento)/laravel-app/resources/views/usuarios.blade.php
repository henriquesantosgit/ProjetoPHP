@extends ('base')

@section('titulo','Laravel')

@section('main')
<h3>Usuários</h3>
<table>
    <tr>
        <th>Nome</th>
        <th>Email</th>
        <th>Ações</th>
    </tr>
@foreach ($users as $user )
<tr>
<td>{{$user->nome}}</td>
<td> {{$user->email}}</td>
 <td><a href="/edit-usuario/{{$user->id}}">Editar</a></td>
 <td>
    <form action="/del-usuario/{{$user->id}}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Excluir">
    </form>  </td>
 
</td>
</tr>
@endforeach
</table>
@endsection