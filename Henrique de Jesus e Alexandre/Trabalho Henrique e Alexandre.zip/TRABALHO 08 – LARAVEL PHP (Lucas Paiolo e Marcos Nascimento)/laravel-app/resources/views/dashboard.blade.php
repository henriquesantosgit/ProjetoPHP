@extends('base')

@section('titulo', 'Dashboard')

@section('main')
<div>
    <h1>Bem-vindo, {{ Auth::user()->nome ?? Auth::user()->email }}!</h1>
    <p>Você está autenticado no sistema.</p>
    <form action="{{ route('logout') }}" method="post">
        @csrf
        <button type="submit">Sair</button>
    </form>
</div>
@endsection
