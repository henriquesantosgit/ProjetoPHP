@extends('base')

@section('titulo', 'Login')

@section('main')
<div id="container-flex">
    <div>
        <h2>Entrar no Sistema</h2>
        <form action="{{ route('login') }}" method="POST">
            @csrf
            <!-- Campo de E-mail -->
            <div>
                <label for="email">E-mail:</label><br>
                <input type="email" name="email" id="email" value="{{ old('email') }}" required>
             
            </div><br>

            <!-- Campo de Senha -->
            <div>
                <label for="password">Senha:</label><br>
                <input type="password" name="password" id="password" required>
                
            </div><br>

            <!-- Botão de Login -->
            <div>
                <button type="submit">Entrar</button>
            </div>
        </form>

   
    </div>
</div>
@endsection
