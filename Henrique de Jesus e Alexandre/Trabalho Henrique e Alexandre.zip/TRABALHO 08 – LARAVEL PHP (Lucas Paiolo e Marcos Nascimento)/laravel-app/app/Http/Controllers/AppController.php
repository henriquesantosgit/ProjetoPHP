<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AppController extends Controller
{
    public function sobre(){
        $nome = "Laravel";
        $nomes = ["PHP","Composer","Laravel"];
        return view('sobre',['nome' => $nome, 'nomes' => $nomes]);
    }

    public function base(){
        return view('base');
    }
    public function exibirUsuarios(){
        
        $usuarios = Usuario::all();

        return view('/usuarios',['users' => $usuarios]);
    }
    public function addUsuario(Request $request){
        $usuario = new Usuario();
        $usuario->nome = $request->fnome;
        $usuario->email = $request->femail;
        $usuario->senha = Hash::make($request->fsenha); // Criptografa a senha
        $usuario->save();
        return redirect('/usuarios');
    }
    public function editUsuario($id){
        // busca o usuário pelo id
        $usuario = Usuario::findOrFail($id);

        // retorna a view com o usuário preenchido
        return view('editar',['user' => $usuario]);

    }
    public function atualizar(Request $request){
        $usuario = Usuario::findOrFail($request->id);
        $dados = [
            'nome' =>$request->fnome, 
            'email'=>$request->femail
        ];
        $usuario->update($dados);
        return redirect('/usuarios');
    }
    public function delUsuario($id){
        $usuario = Usuario::findOrFail($id);
        $usuario->delete();
        return redirect('/usuarios');
    }

}
class AuthController extends Controller
{
    public function login(Request $request)
    {
        // Validação das credenciais
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        // Tentando autenticar o usuário
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            // Redireciona para o dashboard se a autenticação for bem-sucedida
            return redirect()->route('dashboard');
        }

        // Se as credenciais forem inválidas, retorna um erro
        return back()->withErrors(['email' => 'Credenciais inválidas.']);
    }
}
